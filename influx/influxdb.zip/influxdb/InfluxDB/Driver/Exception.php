<?php
/**
 * @author Stephen "TheCodeAssassin" Hoogendijk
 */

namespace InfluxDB\Driver;

/**
 * Class Exception
 *
 * @package InfluxDB\Driver
 */
class Exception extends \InfluxDB\Client\Exception
{

}