<?php

namespace InfluxDB\Database;

/**
 * @author Stephen "TheCodeAssassin" Hoogendijk
 */
class Exception extends \InfluxDB\Exception
{
}
