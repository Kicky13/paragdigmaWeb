<?php

namespace InfluxDB;

/**
 * @author Stephen "TheCodeAssassin" Hoogendijk
 */
class Exception extends \Exception
{
}
