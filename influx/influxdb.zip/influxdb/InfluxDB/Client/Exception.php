<?php

namespace InfluxDB\Client;

/**
 * Class Exception
 *
 * @package InfluxDB\Client
 */
class Exception extends \InfluxDB\Exception
{
}
