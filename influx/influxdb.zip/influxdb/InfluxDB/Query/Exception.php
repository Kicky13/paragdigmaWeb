<?php

namespace InfluxDB\Query;

/**
 * @author Stephen "TheCodeAssassin" Hoogendijk
 */
class Exception extends \InfluxDB\Exception
{
}
